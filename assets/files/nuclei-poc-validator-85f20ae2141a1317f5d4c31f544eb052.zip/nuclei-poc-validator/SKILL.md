---
name: nuclei-poc-validator
description: 对提供的 Nuclei YAML POC 模板进行自动修正，使其符合 Nuclei 官方规范。检测并修复语法错误、补充缺失字段、修正匹配器/提取器、统一标签格式等。当用户提供或粘贴一个 Nuclei YAML 模板并希望自动修复问题时使用。当用户提到 "验证poc"、"检查nuclei模板"、"poc review"、"nuclei template validation"、"poc格式检查"、"修正poc"、"修复模板" 或 "审查yaml" 时也适用。
argument-hint: "[Yaml POC]"
---

# Nuclei POC 自动修正器

对用户提供的 Nuclei YAML POC 模板进行检测并**静默自动修复**，仅输出修正后的完整 YAML。

## 核心原则

1. **只输出修正后的 YAML**，不输出任何评审报告、改动说明、注释
2. **静默修复所有可修复的问题**：语法、结构、缺失字段、格式错误等
3. **仅输出 YAML 代码块**，用户可直接复制保存为 `.yaml` 文件
4. 对于无法确定的内容（如未知的参考链接），使用合理的推断或通用占位值

## 自动修复规则

### 规则 1：id 格式修正

```
修复前: id: my template id          → 修复后: id: my-template-id
修复前: id: My_Template_ID          → 修复后: id: my-template-id
修复前: id: CVE-2024-12345          → 修复后: id: cve-2024-12345
```

- 空格替换为连字符 `-`
- 下划线替换为连字符 `-`
- 全部转为小写

### 规则 2：补充缺失的 info 块字段

逐一检查 9 个必填字段，缺失时自动补充：

| 缺失字段 | 补充策略 |
|---------|---------|
| **name** | 从 `id` 推断：`cve-2024-xxxxx` → `CVE-2024-XXXXX`；从 `tags`/`description` 推断漏洞类型名称 |
| **author** | 若缺失，默认填入 `d4m1ts` |
| **severity** | 根据 `tags`/`description` 推断漏洞类型后按规则匹配；无法推断时默认 `medium` |
| **description** | 根据 `name`、`tags`、`id` 推断生成简述 |
| **impact** | 根据漏洞类型生成对应危害说明 |
| **remediation** | 根据漏洞类型生成通用修复建议 |
| **reference** | 若 `id` 含 `cve-xxxxx-xxxxx`，自动补 `https://nvd.nist.gov/vuln/detail/CVE-XXXX-XXXXX`；否则保留已有项或移除无效项 |
| **metadata.fofa-query** | 若缺失/为空/为占位符，根据 `name` 和 `tags` 推断生成 |
| **tags** | 若缺失，根据 `id`/`name`/`description` 推断漏洞类型后补全 |

**severity 自动推断规则：**

| 从 tags/description 检测到 | 推断 severity |
|---|---|
| `rce`、`command-injection`、`code-execution`、`unauth` | `critical` |
| `sqli`、`auth-bypass`、`lfi`、`rfi`、`ssrf`、`file-upload` | `high` |
| `xss`、`exposure`、`config`、`default-login`、`csrf`、`backup` | `medium` |
| `misconfig`、信息泄露类 | `low` |
| `exposed-panel`、`admin-panel`、`tech`、`fingerprint` | `info` |

**impact / remediation 自动生成参考：**

| 漏洞类型 | impact | remediation |
|---------|--------|-------------|
| RCE | 未认证攻击者可远程执行任意系统命令，完全控制目标服务器。 | 立即升级至最新版本，限制该端点访问。 |
| SQLi | 攻击者可获取数据库中的敏感数据，可能导致数据泄露或篡改。 | 使用参数化查询，对用户输入进行严格过滤。 |
| LFI/RFI | 攻击者可读取服务器上的任意文件，导致敏感信息泄露。 | 对文件路径参数进行白名单校验，禁止路径遍历字符。 |
| XSS | 攻击者可注入恶意脚本，窃取用户 Cookie 或执行未授权操作。 | 对所有用户输入进行 HTML 实体编码输出。 |
| SSRF | 攻击者可利用服务器发起对内网的请求，探测内网服务。 | 对 URL 参数进行白名单限制，禁用内网地址访问。 |
| 文件暴露 | 敏感配置文件可被未授权访问，泄露数据库凭据等关键信息。 | 在 Web 服务器配置中禁止对敏感文件的直接访问。 |
| 认证绕过 | 攻击者可绕过认证机制，直接访问管理后台。 | 修复权限校验逻辑，确保所有接口均需有效认证。 |
| 信息泄露 | 暴露的敏感信息可能被攻击者利用进行进一步渗透。 | 隐藏错误详情，移除调试接口，限制敏感路径访问。 |

**fofa-query 自动生成规则：**
- 若 `name`/`description` 含应用名 → `app="应用名"`  
- 若有关键路径 → 追加 `&& body="路径关键词"`
- 无法推断时 → 使用 `title="login"` 作为兜底（保守查询）

### 规则 3：HTTP 请求结构修正

- **path 缺少 `{{BaseURL}}` 前缀**：自动补全
- **path 不是列表格式**：自动转为列表
- **method 不是标准 HTTP 方法**：根据请求内容推断（有 body → POST，无 body → GET）
- **raw 格式中缺少 Host 头**：自动添加 `Host: {{Hostname}}`
- **raw 格式中缺少 HTTP/1.1**：自动补全请求行

### 规则 4：Matchers 深度修正

**4.1 通用关键词增强**
当 word matcher 只包含黑名单中的通用词时，添加 `condition: and` 并追加状态码匹配：

```
匹配器黑名单: success, ok, error, true, false, null, 200, data, result,
              response, done, complete, admin, user, login, password,
              test, sample, example, default, welcome, home, index,
              submit, save, delete, update, create, read, list, view,
              content, title, header, footer, body, main, page, html
```

修正策略：若检测到仅包含黑名单词的 word matcher，保持不变（无法无上下文地替换），但追加一个 `type: status` 匹配器（若尚未存在）。

**4.2 缺少 matchers 时**
若整个请求块无任何 matchers，根据请求路径和响应特征自动添加基础的 status 匹配器（200）。

**4.3 无 condition 却有多个 keywords**
当 word matchers 包含 2 个或以上 keywords 但未设置 `condition` 时，自动添加 `condition: and`。`condition: and` 是默认且推荐的设置——要求全部关键词同时匹配才命中，最大程度减少误报。

**仅在关键词互斥时才允许 `condition: or`**：即多个关键词不可能在同一个漏洞响应中同时出现，只需匹配其一即可确认漏洞存在。这种情况极为罕见，修正器默认不使用 `or`。

**4.4 part 字段修正**
当匹配器明显针对响应头内容（关键词是常见 HTTP 头值如 `text/html`、`PHPSESSID` 等）但 part 缺失或为 body 时，添加 `part: header`。

**4.5 regex 简化为 word**
当 regex 是纯字符串（不含正则特殊字符如 `.`、`*`、`[`、`(`、`\` 等）时，转换为 `type: word`。

**4.6 matchers-condition 自动补全**
当存在 2 个或以上 matchers 且未设置 `matchers-condition` 时，自动添加 `matchers-condition: and`。

Nuclei 中多个 matchers 默认遵循 OR 逻辑——只要任意一个 matcher 命中即判定漏洞存在。若未设置 `matchers-condition: and`，当 `type: status` 匹配器单独命中（如状态码 200）时，即使 word/regex matcher 未匹配也会产生误报。

```
修复前（误报风险：200 状态码单独命中即判定漏洞存在）:
matchers:
  - type: word
    words:
      - "root:x:0:0:"
  - type: status
    status:
      - 200

修复后:
matchers-condition: and
matchers:
  - type: word
    words:
      - "root:x:0:0:"
  - type: status
    status:
      - 200
```

**例外：** 若模板作者显式设置了 `matchers-condition: or`，则保留原值不修改。

**4.7 condition: or 自动修正为 and**
当 word matcher 包含 2 个或以上 keywords 且显式设置了 `condition: or` 时，自动修正为 `condition: and`。Nuclei 的 `or` 默认行为过于宽松，只要匹配任意一个关键词即判定漏洞存在，极易产生误报。

```
修复前（or 过于宽松，任一关键词命中即判定漏洞）:
matchers:
  - type: word
    words:
      - "admin"
      - "dashboard"
    condition: or

修复后:
matchers:
  - type: word
    words:
      - "admin"
      - "dashboard"
    condition: and
```

**例外：** 仅当多个关键词在语义上确实互斥（不可能在同一响应中同时出现）时保留 `condition: or`，例如同一接口在不同操作系统下返回不同的特征字符串。

### 规则 5：Extractors 自动补全

**5.1 必要性判定 — 必须添加 extractors 的漏洞类型**

以下漏洞类型若缺少 extractors，**必须自动添加**：

| 漏洞类型 | 推断依据 | 添加的 extractors |
|---------|---------|------------------|
| RCE/命令执行 | tags 含 `rce`，id/description 含 `rce`/`command`/`exec` | 从 matchers 中的 word 关键词推断输出模式 |
| LFI/文件包含 | tags 含 `lfi`/`rfi`，path 含 `../` 或 `file=` | regex 捕获文件内容 |
| SQLi | tags 含 `sqli`，description 含 `sql` | regex 捕获数据库错误/输出 |
| SSTI | tags 含 `ssti`，description 含 `template`/`injection` | regex 捕获注入执行结果 |

**5.2 extractors 生成策略：**

```
通用 regex extractor 模板（根据 matchers 中的关键响应特征推断 pattern）:
extractors:
  - type: regex
    name: result
    regex:
      - '<从 matchers.word 中取第一个特征词构造 regex>'
    group: 1
```

- RCE：从 matchers word 构造 regex，如 `uid=\d+\((\w+)\)` → group:1
- LFI：从 matchers word 构造 regex，如 `root:x:0:0:.*` 
- SQLi：构造 SQL 错误/输出 regex，如 `(SQL syntax.*)`、`(database:)`
- SSTI：构造模板引擎输出 regex

### 规则 6：动态变量自动修正

| 错误写法 | 正确写法 |
|---------|---------|
| `{{Baseurl}}` | `{{BaseURL}}` |
| `{{baseURL}}` | `{{BaseURL}}` |
| `{{baseurl}}` | `{{BaseURL}}` |
| `{{Rooturl}}` | `{{RootURL}}` |
| `{{rootURL}}` | `{{RootURL}}` |
| `{{HostName}}` | `{{Hostname}}` |
| `{{hostname}}` | `{{Hostname}}` |
| `{{host}}` | `{{Host}}` |
| `{{scheme}}` | `{{Scheme}}` |
| `{{BaseURL}}/api`（路径以 // 开头） | `{{BaseURL}}/api`（去除多余斜杠） |
| `{{Target}}`、`{{Random}}` 等不存在变量 | 替换为 `{{BaseURL}}`（最可能的意图） |

### 规则 7：标签自动修正

- **缺失漏洞类型标签**：根据 id/name/description 推断并补全
- **CVE 标签缺失**：若 id 匹配 `cve-\d{4}-\d{4,}`，自动添加 `cve` 标签和具体 CVE 编号标签
- **标签大小写**：全部转为小写
- **标签分隔符**：确保逗号后有空格（或没有空格，统一为逗号+单空格）

### 规则 8：severity 自动修正

当 severity 与漏洞类型严重不匹配时自动修正：

| 场景 | 修正 |
|------|------|
| RCE/命令执行 → severity 不是 `critical` | → `critical` |
| SQLi/LFI/SSRF/认证绕过 → severity 是 `low`/`info` | → `high` |
| 暴露面板/版本检测 → severity 是 `critical` | → `info` |
| XSS/信息泄露 → severity 是 `critical` | → `medium` |

### 规则 9：YAML 格式与缩进修正

- 确保 `info` 块下所有字段使用一致的 2 空格缩进
- 列表项 `- ` 后确保有空格
- `reference` 下的 URL 如缺少 `- ` 前缀则补全
- 多行字符串确保使用 `|` 或 `|-` 操作符
- 移除重复的 key（保留最后一个）

## 修正内容不输出原则

**绝对禁止输出以下任何内容：**
- 评审报告、得分、问题清单
- "修复了以下问题" 或任何改动摘要
- YAML 内部的注释说明修改了什么
- 修复前后对比
- "以下是修正后的模板" 之类的引导语

**只允许输出：**
- 一个包含修正后完整 YAML 的代码块

## 输出格式

```yaml
id: corrected-template-id

info:
  name: 修正后的模板名称（需修正为简体中文）
  author: d4m1ts
  severity: high
  description: 修正后的漏洞描述。（需修正为简体中文）
  impact: 漏洞造成的实际危害。（需修正为简体中文）
  remediation: 修复建议。（需修正为简体中文）
  reference:
    - https://example.com
  metadata:
    fofa-query: 'app="Example"'
  tags: example,tag,corrected

http:
  - method: GET
    path:
      - "{{BaseURL}}/fixed-path"
    matchers-condition: and
    matchers:
      - type: word
        words:
          - "specific-keyword"
          - "another-keyword"
        condition: and
      - type: status
        status:
          - 200
```

> 注意：示例仅供参考格式，实际输出必须是根据用户输入修正后的完整 YAML，不可包含注释。

## 参考资源

- Nuclei 官方模板语法：https://docs.projectdiscovery.io/templates/reference
- Nuclei 模板示例仓库：https://github.com/projectdiscovery/nuclei-templates
- Fofa 搜索语法：https://fofa.info/library
- 动态变量完整参考：
  - `{{BaseURL}}` — 完整 URL（协议+主机+端口+路径）
  - `{{RootURL}}` — 根 URL（协议+主机+端口）
  - `{{Hostname}}` — 主机名+端口
  - `{{Host}}` — 仅主机名
  - `{{Port}}` — 端口号
  - `{{Path}}` — URL 路径
  - `{{File}}` — 路径中的文件名
  - `{{Scheme}}` — 协议方案
  - `{{interactsh-url}}` — OOB 交互地址

## 匹配器类型快速参考

```yaml
# word — 关键词匹配
matchers:
  - type: word
    words: ["keyword1", "keyword2"]
    condition: and   # 默认值：全部关键词匹配才命中；仅在关键词互斥时使用 or

# regex — 正则匹配
matchers:
  - type: regex
    regex: ["pattern.*"]
    part: body

# status — 状态码匹配
matchers:
  - type: status
    status: [200, 201]

# dsl — 表达式匹配
matchers:
  - type: dsl
    dsl:
      - "status_code == 200 && contains(body, 'keyword')"
```

## 提取器快速参考

```yaml
# regex 提取器 — 最常用
extractors:
  - type: regex
    name: result_name
    regex: ["capture_(.*)"]
    group: 1

# json 提取器
extractors:
  - type: json
    name: field_name
    json: ['.[] | .field']
    part: body

# kval 提取器 — 响应头键值提取（短划线→下划线）
extractors:
  - type: kval
    kval:
      - content_type
```

## 常见漏洞类型模板骨架

### RCE POC 骨架（修复后输出参考）

```yaml
id: target-rce
info:
  name: TargetApp 远程代码执行
  author: d4m1ts
  severity: critical
  description: TargetApp 存在未授权远程代码执行漏洞。
  impact: 未认证攻击者可远程执行任意系统命令，完全控制目标服务器。
  remediation: 升级至最新版本，限制该端点访问。
  reference:
    - https://nvd.nist.gov/vuln/detail/CVE-XXXX-XXXXX
  metadata:
    fofa-query: 'app="TargetApp"'
  tags: rce,unauth
http:
  - method: POST
    path:
      - "{{BaseURL}}/vuln-endpoint"
    body: 'cmd=id'
    matchers-condition: and
    matchers:
      - type: word
        words:
          - "uid="
          - "gid="
        condition: and
      - type: status
        status:
          - 200
    extractors:
      - type: regex
        name: cmd_result
        regex:
          - 'uid=\d+\((\w+)\)'
        group: 1
```

### LFI POC 骨架（修复后输出参考）

```yaml
id: target-lfi
info:
  name: TargetApp 本地文件包含
  author: d4m1ts
  severity: high
  description: TargetApp 存在路径遍历漏洞，可读取服务器敏感文件。
  impact: 攻击者可读取服务器上的任意文件，导致敏感信息泄露。
  remediation: 对文件路径参数进行白名单校验，禁止路径遍历字符。
  reference:
    - https://example.com/advisory
  metadata:
    fofa-query: 'body="file="'
  tags: lfi,path-traversal
http:
  - method: GET
    path:
      - "{{BaseURL}}/view?file=../../../../etc/passwd"
    matchers:
      - type: word
        words:
          - "root:x:0:0:"
          - "/bin/bash"
        condition: and
    extractors:
      - type: regex
        name: file_content
        regex:
          - 'root:x:0:0:.*'
```


